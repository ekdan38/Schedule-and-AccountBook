package com.example.scheduleandaccountbook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Result_Activity extends AppCompatActivity {
    final String TAG = this.getClass().getSimpleName();
    //////////////////////////////////////하단 메뉴바
    LinearLayout home_ly;
    BottomNavigationView bottomNavigationView;
    //////////////////////////////////////하단 메뉴바


    private TextView tv_result; // 닉네임 text
    private ImageView iv_profile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Intent intent = getIntent();
        String nickName = intent.getStringExtra("nickname");
        String photoUrl = intent.getStringExtra("photoUrl");

        tv_result = findViewById(R.id.textView2);
        tv_result.setText(nickName);

        iv_profile = findViewById(R.id.imageView2);
        Glide.with(this).load(photoUrl).into(iv_profile);

//////////////////////////////////////하단 메뉴바
        init(); //객체 정의
        SettingListener(); //리스너 등록

        //맨 처음 시작할 탭 설정
        bottomNavigationView.setSelectedItemId(R.id.tab_calendar);
    }
    private void init() {
        home_ly = findViewById(R.id.home_ly);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
    }
    private void SettingListener() {
        //선택 리스너 등록
        bottomNavigationView.setOnNavigationItemSelectedListener(new TabSelectedListener());
    }

    class TabSelectedListener implements BottomNavigationView.OnNavigationItemSelectedListener{
        @Override
        public boolean onNavigationItemSelected(MenuItem menuItem) {
            switch (menuItem.getItemId()) {
                case R.id.tab_calendar: {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.home_ly, new calendar())
                            .commit();
                    return true;
                }
                case R.id.tab_accountbook: {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.home_ly, new accountbook())
                            .commit();
                    return true;
                }
                case R.id.tab_user: {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.home_ly, new user())
                            .commit();
                    return true;
                }
            }

            return false;
        }
    }
}